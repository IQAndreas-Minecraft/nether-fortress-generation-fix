
All rights reserved Andreas Renberg (IQAndreas)
http://minecraft.iqandreas.com/ 

Any sharing or redistribution of the source code or binaries without the author's permission is strictly forbidden.

Parts of the code owned by Mojang AB.

